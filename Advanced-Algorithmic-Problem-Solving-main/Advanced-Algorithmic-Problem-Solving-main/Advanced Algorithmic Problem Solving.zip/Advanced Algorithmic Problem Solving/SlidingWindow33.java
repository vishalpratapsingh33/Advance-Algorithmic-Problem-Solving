//The sliding window is a subarray that "slides" across the main array:
//
//We use two pointers (start and end) to define the boundaries of a window.
//
//Instead of recalculating from scratch, we reuse previous results and adjust as the window moves.
//
