////A subset is a selection of elements from a set, where the order doesn't matter. A subset can include some or all of the elements from the original set, or even none (the empty set).
//
//A permutation refers to an arrangement of elements from a set, where the order of the elements does matter. For permutations, we're concerned with different ways to arrange a subset of the original set.